HOW TO PUBLISH (about 2 minutes)

Option A — Netlify Drop (no account needed to start)
  1. Go to https://app.netlify.com/drop
  2. Drag this whole folder (the one containing index.html) onto the page
  3. You get a URL like https://random-name-123.netlify.app
  4. Optional: create a free account to rename it, e.g. leela-gangreddy.netlify.app

Option B — GitHub Pages
  1. Create a public repo, e.g. "portfolio"
  2. Upload everything in this folder to the repo root
  3. Settings > Pages > Source: main branch, root folder
  4. URL becomes https://<username>.github.io/portfolio/

Live at: https://leelagangreddy.netlify.app  (re-drop this folder on Netlify to update)

Files:
  index.html                                     hub page (this is what the URL opens)
  Leela_Gangreddy_Product_Portfolio.pdf          five-case-study PDF
  prototypes/realtime-queue-status-ai.html       Case study 05 prototype
  prototypes/compliance-reference-multi-domain-v3.html   Case study 04, v3.0
  prototypes/compliance-reference-v1.html        Case study 04, v1.0

NOT included on purpose: the Real Time Agent Status file — it contains
real-looking agent names and a voxai.com email. Reseed it to Northwind
names first, then drop it into /prototypes and add a card on index.html.
